﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CERTAMEN1DANIELPARDO
{
    class JEFEDIRECTO: Entity
    {
        
        public int rut { get; set; }

        public string domicilio { get; set; }

        public int telefono { get; set; }

        public string profesion { get; set; }

        public JEFEDIRECTO(int id, string nombre, int rut, string domicilio, int telefono, string profesion)
        {
            this.id = id;
            this.nombre = nombre;
            this.rut = rut;
            this.domicilio = domicilio;
            this.telefono = telefono;
            this.profesion = profesion;
        }

        public JEFEDIRECTO()
        {
        }
    }


}
