﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    interface ICrud
    {
        public ResponseExec Create(T o);
        public T GetById(T o);
        public List<T> GetQuery(T o);
        public List<T> Get(T o);
        public ResponseExec Update(T o);
        public ResponseExec Delete(T o);
    }
}
